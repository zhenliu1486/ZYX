# 四个操作：init / ingest / query / lint

> 每个操作都是可重复的流程；写操作一律先取单写锁，违反即拒绝（脚本会拦）。

## 0. 通用前置（每次进入）

1. **定位库**：`python3 scripts/wiki.py resolve [<slug>]` 拿库根；未注册先 `init` 或 `mount`。
2. **读规则**：库内 `schema.md`；再读 `wiki/hot.md`（≤500 字热缓存）与 `wiki/index.md`。
3. **取锁**：`python3 scripts/wiki.py lock <slug>`。已有持锁 → 停止，提示用户或其他会话；确认陈旧（默认 >12h）才 `--force` 接管。
4. **收工释放**：`python3 scripts/wiki.py unlock <slug>`。

## 1. `init` — 建库

触发：「给我建一个关于 X 的知识库 / 资料库 / Obsidian 库」。

1. `wiki.py init <slug> --topic "X"`；用户已有 Obsidian 库时改用 `wiki.py mount <slug> <路径>`。
2. 生成骨架后，向用户确认三件事：主题范围、原料从哪来、是否已有 Obsidian 库要接。
3. 写一条 `log init`，并把主题写进 `overview.md`。

## 2. `ingest` — 摄入编译（核心）

触发：「把这篇文章/这本书/这段转写加进我的 X 库」「ingest raw/...」。

1. **确认原料落位**：文件在 `raw/` 下（只读层）；没有就先放进去，不直接改 wiki。
2. **先验记录**（复用 `../../zyx/shared/verification/incremental-check.md`）：用 3–5 条写下「关于这个主题，我默认已经知道什么」。
3. **读原料**：抓出 3–5 条关键 takeaways，先与人确认重点（Karpathy 建议一次一份、保持参与）。
4. **建来源摘要页**：`wiki.py new-page source <slug> --title "..."`，补 `source_file`、作者、日期、`key_claims`、`related`、`confidence`。
5. **更新相关页**：逐个更新涉及的 concept / entity 页；新信息与旧结论冲突时**不改旧文**，加 `> [!contradiction]` 保留双方与依据。
6. **补新建页**：原料引入的新概念/新实体，过一遍三重验证（`../../zyx/shared/verification/triple-verification.md`）再建页；来源不够的放摘要页「待核查」，不硬造独立页。
7. **更新索引**：新页挂到 `index.md` 对应集群；集群不存在就新建一节。
8. **回写热缓存**：重写 `hot.md`，只留当前最相关上下文。
9. **记日志**：`wiki.py log ingest "<标题>" --detail "新增页: ...；更新页: ...；矛盾: ..."`。
10. **释放锁**，向用户回传：动了哪些页、哪条是增量、哪些存疑。

> 正常一份原料牵动 5–15 个页面；只建一个摘要页就收工，通常说明第 5、6 步漏了。

## 3. `query` — 库内问答

触发：「我库里关于 X 都有什么结论」「按我的库回答这个问题」。

1. 读 `index.md` 定位相关页，只读命中的页，不全库扫。
2. 带 `[[wikilink]]` 引用组织答案；区分「库里明说的」与「我推断的」。
3. 答案有价值时**提议归档**：`wiki.py archive comparison|synthesis <slug> --link-from <来源页>`，一条命令完成建页 + 回链 + 写日志。
4. 若库内没有相关内容：直说没有，给出建议补哪类原料；不拿常识冒充库内结论。
5. 记 `log query`；释放锁（只读问答可只在归档时取锁）。

## 3.5 检索、回链与归档（脚本化）

| 动作 | 命令 | 说明 |
|---|---|---|
| 库内检索 | `wiki.py search "关键词" [--type concept] [--limit 20]` | 只读；命中为空返回 1，方便判断“库里确实没写过” |
| 单条回链 | `wiki.py backlink <来源页> <目标页>` | 幂等；在目标页末尾「关联（自动回链）」段追加 `see also` |
| 建页即互链 | `wiki.py new-page concept <slug> --link-to <已有页> --backlink` | 新页链出去，同时对方页加回链 |
| 问答归档 | `wiki.py archive comparison\|synthesis <slug> --link-from <页>...` | 建归档页 + 给来源页加回链 + 自动写 `log query` |
| 晋级自查 | `wiki.py promote-check <页>` | 只读打分：来源/可信度/关联/可执行步骤/边界；仅候选筛查，不阻断 |

归档闭环：`search` 定位 → 读页作答 → `archive` 落页并回链 → `index.md` 挂上 → 下次 `lint` 能看见它。

## 4. `lint` — 健康巡检

触发：「体检一下我的库」「巡检」「lint」。

1. 跑 `python3 scripts/wiki-lint.py <vault> [--json]`；只读，不写库。
2. 按报告排序处理：断链 / frontmatter → 缺页 / 孤儿 → 索引覆盖 → 陈旧 / 矛盾。
3. 修完记 `log lint`，并把结论写进 `hot.md` 的「未决问题」。

**不设覆盖度闸门**：报告只给客观统计与建议，不输出「覆盖不足禁止下结论」。库能不能用来判断，由使用者自己定；LLM 只负责把缺口说清楚。

## 5. 单写与并发（硬规则）

- **一个库同一时刻只允许一个写会话**：任何写页、写日志、改索引前必须持锁。
- **禁止并行写同一库**：检测到他人持锁就停，不排队硬写、不跳过锁（`WIKI_ALLOW_UNLOCKED=1` 仅供人工排障）。
- **多会话写同一库**：所有会话共用注册表里的**同一个活动库**；不同库之间互不影响，但同一库内串行。
- 锁文件在 `zyx/state/locks/<slug>.lock`，不在库目录，不污染 Obsidian。
- 锁陈旧判断默认 12 小时（`WIKI_LOCK_TTL_HOURS` 可调）；接管用 `--force`，接管后先核对上一次写到哪。

## 6. 与 zyx 其他路由的衔接

| 情况 | 去向 |
|---|---|
| 某份原料在库里已沉淀出独立复用价值，要打包成可安装 Skill | 先 `promote-check` 自查，再晋级 R3 仓颉；判据 = 过三重验证（来源/可执行/增益）+ 具备独立复用价值 |
| 要深挖一个人 / 一个行业的完整打法，而非只存资料 | R1 女娲 / R2 大师，wiki 只存摘要与链接 |
| 某页结论被否、要按反馈改版 | R6 f2r 把反馈显性化为规则，迭代后回写 wiki |
| 只是眼下要一个判断，不要求进长期库 | R4 dbs，不建库 |

## 7. 降级与错误

- 库目录不可写 → 报错并给替代路径，不静默写到别处。
- `wiki/` 缺失 → 不擅自创建用户库结构，先报告；用户同意后 `--provision`。
- 锁被占 → 退出码 3；未持锁写 → 退出码 5；页面已存在 → 退出码 4（不覆盖）。
- 原料含手机号/身份证/客户名 → 先脱敏再入库，沿用 `../../zyx/shared/quality/qa-audit.md`。
- `lint --exit-code` 仅供 CI/批处理用（结构性有问题返回 1），默认恒 0，不代表覆盖度判定。
