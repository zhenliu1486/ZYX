# 06 · 术语对照与索引

两块内容：**中英术语对照**（写英文提示词、读英文资料时用）与 **GrokFilm 300 条索引映射**（查示例片、做教案引用时用）。

---

## 一、中英术语对照

### 景别 Distance
| 中文 | 英文 | 缩写 | 索引 |
|---|---|---|---|
| 大远景 | Extreme Long Shot | ELS | 008 |
| 远景 / 全景 | Wide Shot / Full Shot | WS | 244 |
| 定场镜头 | Establishing Shot | — | 006 |
| 中景 | Medium Shot | MS | 018 |
| 中近景 | Medium Close-Up | MCU | 105 |
| 近景 / 特写 | Close-Up | CU | 003 |
| 大特写 | Extreme Close-Up | ECU | 007 |
| 微距 | Macro | — | — |
| 插入镜头 | Insert Shot | — | 014 |
| 双人镜 | Two-Shot | — | 102 |
| 主镜头 | Master Shot | — | 017 |

### 机位与角度 Height & Tilt
| 中文 | 英文 | 索引 |
|---|---|---|
| 平视 | Eye-Level | 009 |
| 低角度 | Low Angle | 016 |
| 高角度 | High Angle | 013 |
| 俯拍正扣 | Overhead / Top Shot | 020 |
| 鸟瞰 | Bird's Eye View | 002 |
| 航拍 | Aerial | 001 |
| 直升机航拍 | Helicopter Shot | 012 |
| 虫视 | Worm's Eye View | 116 |
| 斜角 | Dutch Angle / Canted | 004 |
| 地面机位 | Ground-Level | — |

### 朝向 Facing
| 中文 | 英文 | 索引 |
|---|---|---|
| 正面 | Frontal | — |
| 侧面 | Profile | 240 |
| 四分之三 | Three-Quarter | — |
| 背面 | Rear View | — |
| 过肩 | Over-the-Shoulder | 019 |
| 第一人称 | POV / Point of View | — |
| 自拍 | Selfie | — |
| 反打 | Reverse Angle | 241 |

### 运动 Movement
| 中文 | 英文 | 索引 |
|---|---|---|
| 固定 | Static / Locked-Down | 112 / 115 |
| 推进 | Push In / Dolly In | 109 / 229 |
| 拉出 | Pull Out / Dolly Out | 110 / 230 |
| 摇 | Pan | 021 |
| 甩镜 | Whip Pan | 101 |
| 俯仰 | Tilt | 100 |
| 平移 / 跟拍 | Tracking | 026 / 235 |
| 升降 | Crane | 028 |
| 升降台 | Pedestal | 234 |
| 环绕 | Arc Shot / Orbit | 227 |
| 手持 | Handheld | 010 |
| 斯坦尼康 | Steadicam | 025 |
| 变焦 | Zoom | 108 / 113 |
| 推轨变焦 | Dolly Zoom | 231 |

### 焦点与光学 Lens & Focus
| 中文 | 英文 | 索引 |
|---|---|---|
| 浅景深 | Shallow Focus | 063 |
| 深焦 | Deep Focus | 064 |
| 摇焦 | Rack Focus | 023 |
| 散景 | Bokeh | 092 |
| 畸变 | Lens Distortion | 203 |
| 光斑 / 眩光 | Lens Flare | 044 |

### 构图 Composition
| 中文 | 英文 | 索引 |
|---|---|---|
| 三分法 | Rule of Thirds | 058 |
| 居中构图 | Centered Composition | 162 |
| 对称 | Symmetry | 059 |
| 引导线 | Leading Lines | 060 |
| 画框内画框 | Framing Within Frame | 061 |
| 负空间 | Negative Space | 062 |
| 前景兴趣点 | Foreground Interest | 158 |
| 图底关系 | Figure-Ground Relationship | 167 |
| 三角构图 | Triangular Composition | 161 |
| 剪影 | Silhouette | 036 |

### 连续性 Continuity
| 中文 | 英文 | 索引 |
|---|---|---|
| 180 度法则 | 180-Degree Rule | 138 |
| 30 度法则 | 30-Degree Rule | 139 |
| 反应镜头 | Reaction Shot | 143 |

> 索引列为 GrokFilm 300 条索引中的编号（grokfilm.app）。标 `—` 的表示该索引内**没有**对应条目，不是遗漏。

---

## 二、索引里没有的五件事（注意）

这五项在 GrokFilm 300 条里查不到，写提示词时容易以为"没有这个概念"：

1. **第一人称 POV** — 索引里没有独立条目。
2. **四分之三侧** — 没有。
3. **自拍视角** — 没有。
4. **地面机位（Ground-Level）** — 没有。
5. **运动模糊 / 快门角度** — 没有（属技术参数层）。

需要时按本技能 `01`、`02` 的句式自己写。

---

## 三、29 条带示例片条目的用途索引（做教案时按这个选片）

| 想讲 | 用哪条的示例片 |
|---|---|
| 空间与尺度怎么建立 | 001 航拍 / 008 大远景 / 012 直升机 |
| 人的权力关系怎么变 | 013 高角度 / （低角度无片）/ 002 鸟瞰 |
| 情绪怎么放大 | 003 特写 / 007 大特写 |
| 不安怎么制造 | 004 荷兰角 |
| 平面图形感 | 002 鸟瞰 / 058 三分 |
| 运动与透视 | 005 推轨 / 025 斯坦尼康 / 231 推轨变焦 |
| 时间的压缩 | 153 延时 / 046 交叉剪辑 |
| 空间与调度 | 065 场面调度 |
| 材质与年代 | 270 暗角 / 271 复古胶片 |
| 类型的整套美术 | 279 哥特恐怖 / 281 日式恐怖 / 285 新西部 |
| 象征怎么立 | 194 象征 |

> 完整 29 条（含视频与提示词）见飞书文档《GrokFilm 影像语法图鉴》。
