---
name: zyx-installer
description: 当用户说「帮我安装 zyx 这个 skill」「安装 ZYX 调度台」「部署 zyx」「装一下 zyx」时使用。这个技能是 ZYX 的安装器，不是 ZYX 本体；它把本包内的完整 ZYX 多技能仓库安装到当前设备，不执行具体业务任务。
metadata:
  version: "1.0.0"
---

# ZYX Installer

ZYX 是 16 个技能的多技能包，根目录故意没有单个 `SKILL.md`。不要把它当作一个普通技能安装，也不要去 GitHub 搜索“zyx skill”。

## 执行

1. 先确认本技能目录里有 `repo/skills/` 和 `bootstrap.sh`。
2. 在本技能目录执行：

```bash
bash bootstrap.sh
```

不传参数会自动探测宿主 skills 目录，并安装内置技能与外部依赖。只想装技能本体：

```bash
bash bootstrap.sh --no-deps
```

指定目录：

```bash
bash bootstrap.sh --dir ~/.claude/skills
```

3. 安装完成后运行：

```bash
bash repo/skills/zyx/scripts/doctor.sh --full
```

看到「全部就绪」即完成。新开一个对话，直接说「用 ZYX 帮我……」。
